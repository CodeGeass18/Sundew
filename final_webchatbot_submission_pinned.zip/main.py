import streamlit as st
from app.chatbot_core import ChatbotApp

def main():
    st.set_page_config(page_title="Sundew — Website Assistant", layout="wide")
    app = ChatbotApp()
    app.run()

if __name__ == "__main__":
    main()
