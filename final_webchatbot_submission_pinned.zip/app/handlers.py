from typing import Optional
import streamlit as st

def initial_promo(app):
    # A short Sundew services promotion with quick-action buttons
    st.markdown("### 👋 Welcome to Sundew (Pravartan.ai Demo Assistant)")
    st.write("We help businesses with AI products, data pipelines, and automation. Choose an option below to get started:")
    col1, col2, col3 = st.columns(3)
    if col1.button("I'm a potential client"):
        st.session_state.flow = "client"
        st.session_state.greeted = True
        st.experimental_rerun()
    if col2.button("I'm a job seeker"):
        st.session_state.flow = "jobseeker"
        st.session_state.greeted = True
        st.experimental_rerun()
    if col3.button("I want info"):
        st.session_state.flow = "info"
        st.session_state.greeted = True
        st.experimental_rerun()

def handle_user_message(app, message: str) -> str:
    # Simple rule-based guided flows to demonstrate functionality.
    m = message.lower()
    # capture name
    if m.startswith("my name is ") or m.startswith("i am ") or m.startswith("i'm "):
        name = message.split(" ",2)[-1].strip().title()
        st.session_state.user_name = name
        return f"Nice to meet you, {name}! How can I help you today?"
    # flows
    if st.session_state.flow == "client" or "client" in m:
        return client_flow(message)
    if st.session_state.flow == "jobseeker" or "job" in m:
        return jobseeker_flow(message)
    if st.session_state.flow == "info" or "info" in m or "help" in m:
        return info_flow(message)
    # generic intents
    if "services" in m or "offer" in m:
        return client_flow(message)
    if "career" in m or "job" in m or "openings" in m:
        return jobseeker_flow(message)
    # fallback
    return ("I'm a demo assistant. I can guide you to services, careers, or information. "
            "Try: 'I'm a client', 'I'm a job seeker', or ask 'what services do you offer?'")

def client_flow(message: str) -> str:
    return ("We offer: 1) Generative AI integrations, 2) Data pipelines & warehousing, 3) NLP & search. "
            "Would you like contact details or a one-page service summary? Reply 'contact' or 'summary'.")

def jobseeker_flow(message: str) -> str:
    return ("We regularly hire for AI/ML, SDE, and Data roles. Upload your resume at careers@pravartan.ai "
            "or reply 'openings' to see current roles (demo).")

def info_flow(message: str) -> str:
    return ("You can explore our docs in the site data folder (demo). What topic are you interested in? "
            "e.g., 'RAG', 'Deployment', or 'Pricing'.")