import streamlit as st
from utils.email_validator import is_valid_email
from utils.logger import ChatLogger
from app.handlers import handle_user_message, initial_promo

class ChatbotApp:
    def __init__(self):
        self.logger = ChatLogger(log_dir="chat_logs")
        if "initialized" not in st.session_state:
            st.session_state.initialized = True
            st.session_state.user_email = ""
            st.session_state.user_name = ""
            st.session_state.greeted = False
            st.session_state.flow = None

    def run(self):
        st.title("Sundew — Website Assistant (Demo)")
        with st.sidebar:
            st.header("Session")
            st.write("Use `career@pravartan.ai` as the business email for testing if needed.")
            if st.session_state.user_email:
                st.write(f"Email: {st.session_state.user_email}")
            if st.button("Clear chat logs (local)"):
                self.logger.clear_logs()
                st.success("Chat logs cleared.")

        # Email capture / validation
        if not st.session_state.user_email:
            st.info("Please enter your business email to start chatting.")
            email = st.text_input("Business email", key="input_email")
            if st.button("Start chat"):
                if is_valid_email(email):
                    st.session_state.user_email = email
                    self.logger.create_session(email)
                    st.experimental_rerun()
                else:
                    st.error("Please enter a valid business email (e.g., name@company.com).")
            return

        # Main chat UI
        chat_placeholder = st.empty()
        with chat_placeholder.container():
            # Show promo once per session
            if not st.session_state.greeted:
                initial_promo(self)
                st.session_state.greeted = True

            st.markdown("---")
            user_input = st.text_input("You:", key="user_input")
            col1, col2 = st.columns([1,5])
            with col1:
                if st.button("Send"):
                    if user_input and user_input.strip():
                        response = handle_user_message(self, user_input.strip())
                        st.session_state.last_response = response
                        self.logger.log_message(role="user", message=user_input.strip())
                        self.logger.log_message(role="bot", message=response)
                        st.experimental_rerun()
                    else:
                        st.warning("Please enter something to send.")
            with col2:
                # show most recent exchange
                if "last_response" in st.session_state:
                    st.markdown("**Bot:** " + st.session_state.last_response)

            st.write("Tip: Try typing 'I am a client', 'I am a job seeker' or ask for 'services'.")
