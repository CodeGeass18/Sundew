# Chatbot Enhancement — Submission Draft

**Name:** <Your Name>
**Email:** <your.email@example.com>
**Project:** Sundew — Website Assistant (Pravartan.ai Coding Test)
**Date:** 12 August 2025

## Summary of changes
- Modularized original `Web_Chatbot.py` into `app/` and `utils/`.
- Added promotional welcome flow (Sundew Services Promotion) with quick-action buttons.
- Implemented guided flows for Clients, Job Seekers, and Info Seekers.
- Implemented chat logging: session JSON files saved under `chat_logs/`.
- Added simple personalization: capture and greet by name/email.
- Created a cleaner `main.py` for `streamlit run main.py` entrypoint.
- Added this documentation and a sample `requirements.txt` (CPU-friendly).

## How to run (local)
1. Create a fresh Python venv (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux / macOS
   venv\\Scripts\\activate    # Windows
   ```
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   streamlit run main.py
   ```
4. For testing, enter business email `career@pravartan.ai` to start the chat.

## Deployment research (summary)
**Options tested / recommended:**

### Streamlit Cloud
- Pros: fastest to deploy, integrates with GitHub, free tier for demos.
- Cons: limited compute, not ideal for heavy model inference.

### Hugging Face Spaces (Gradio/Streamlit)
- Pros: easy, good for public demos; supports GPU for selected runtimes.
- Cons: public by default, storage limits on free tier.

### AWS (EC2 / Elastic Beanstalk)
- Pros: full control, scalable, supports GPUs and production configs.
- Cons: more setup required; cost for compute and infra.

## Step-by-step (example: Streamlit Cloud)
1. Push repository to GitHub.
2. Sign in to Streamlit Cloud and create a new app, link the GitHub repo and branch.
3. Set required environment variables (if any) in the Streamlit Cloud settings.
4. Launch — the app will be served at a Streamlit-managed URL.

## Files included in submission
- `main.py`, `app/`, `utils/`, `data/`, `chat_logs/`, `requirements.txt`, `deployment_and_documentation.md`

## Notes and next steps (ideas for extra credit)
- Integrate with a real LLM (OpenAI, local LLM) using a safe prompt template and response verifier.
- Add analytics pipeline to summarize chat logs and surface lead signals.
- Add resume-upload feature for jobseekers and attachment email sending.
