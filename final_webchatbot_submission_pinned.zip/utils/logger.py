import os, json, time
from datetime import datetime

class ChatLogger:
    def __init__(self, log_dir="chat_logs"):
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.session_file = None

    def create_session(self, email):
        ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        safe_email = email.replace("@", "_at_").replace(".", "_")
        filename = f"session_{safe_email}_{ts}.json"
        self.session_file = os.path.join(self.log_dir, filename)
        # initialize
        with open(self.session_file, "w") as f:
            json.dump({"email": email, "messages": [], "created_at": ts}, f, indent=2)

    def log_message(self, role, message):
        if not self.session_file:
            # create a default anonymous session
            self.create_session("anonymous")
        entry = {"role": role, "message": message, "ts": datetime.utcnow().isoformat()}
        with open(self.session_file, "r+") as f:
            data = json.load(f)
            data["messages"].append(entry)
            f.seek(0)
            json.dump(data, f, indent=2)
            f.truncate()

    def clear_logs(self):
        # remove everything in log_dir
        for f in os.listdir(self.log_dir):
            fp = os.path.join(self.log_dir, f)
            try:
                os.remove(fp)
            except Exception:
                pass
