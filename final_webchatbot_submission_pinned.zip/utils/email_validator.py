import re

def is_valid_email(email: str) -> bool:
    if not email or "@" not in email:
        return False
    # simple regex for business email
    pattern = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
    return re.match(pattern, email) is not None
